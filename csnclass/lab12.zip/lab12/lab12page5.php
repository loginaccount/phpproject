
<br>

<br>
<img src='lab12/lab12images/louis.jpg'>
<br>

<br>

<h1>Louis Armstrong</h1>




<br>
Louis Armstrong (August 4, 1901 – July 6, 1971), nicknamed Satchmo or Pops, was an American jazz trumpeter, composer and singer who became one of the pivotal and most influential figures in jazz music. His career spanned five decades, from the 1920s to the 1960s, and different eras in jazz.

Coming to prominence in the 1920s as an "inventive" trumpet and cornet player, Armstrong was a foundational influence in jazz, shifting the focus of the music from collective improvisation to solo performance. With his instantly recognizable gravelly voice, Armstrong was also an influential singer, demonstrating great dexterity as an improviser, bending the lyrics and melody of a song for expressive purposes. He was also skilled at scat singing.

Renowned for his charismatic stage presence and voice almost as much as for his trumpet-playing, Armstrong's influence extends well beyond jazz music, and by the end of his career in the 1960s, he was widely regarded as a profound influence on popular music in general. Armstrong was one of the first truly popular African-American entertainers to "cross over", whose skin color was secondary to his music in an America that was extremely racially divided. He rarely publicly politicized his race, often to the dismay of fellow African-Americans, but took a well-publicized stand for desegregation in the Little Rock Crisis. His artistry and personality allowed him socially acceptable access to the upper echelons of American society which were highly 

<br>