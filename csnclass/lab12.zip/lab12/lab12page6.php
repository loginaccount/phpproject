<br>

<br>
<img src='lab12/lab12images/elvis.jpg'>
<br>

<br>

<h1>Elvis Presley</h1>

<br>

Elvis Aaron Presley (January 8, 1935 – August 16, 1977) was an American singer and actor. Regarded as one of the most significant cultural icons of the 20th century, he is often referred to as "the King of Rock and Roll", or simply, "the King".

Presley was born in Tupelo, Mississippi, as a twinless twin, and when he was 13 years old, he and his family relocated to Memphis, Tennessee. His music career began there in 1954, when he recorded a song with producer Sam Phillips at Sun Records. Accompanied by guitarist Scotty Moore and bassist Bill Black, Presley was an early popularizer of rockabilly, an uptempo, backbeat-driven fusion of country music and rhythm and blues. RCA Victor acquired his contract in a deal arranged by Colonel Tom Parker, who managed the singer for more than two decades. Presley's first RCA single, "Heartbreak Hotel", was released in January 1956 and became a number-one hit in the United States. He was regarded as the leading figure of rock and roll after a series of successful network television appearances and chart-topping records. His energized interpretations of songs and sexually provocative performance style, combined with a singularly potent mix of influences across color lines that coincided with the dawn of the Civil Rights Movement, made him enormously popular—and controversial.
<br>

