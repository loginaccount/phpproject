<br>

<br>
<img src='lab12/lab12images/bob.jpg'>
<br>

<br>
<h1>Bob Dylan</h1>
<br>

Bob Dylan (/ˈdɪlən/; born Robert Allen Zimmerman, May 24, 1941) is an American singer-songwriter, artist and writer. He has been influential in popular music and culture for more than five decades. Much of his most celebrated work dates from the 1960s when his songs chronicled social unrest, although Dylan repudiated suggestions from journalists that he was a spokesman for his generation. Nevertheless, early songs such as "Blowin' in the Wind" and "The Times They Are a-Changin'" became anthems for the American civil rights and anti-war movements. After he left his initial base in the American folk music revival, his six-minute single "Like a Rolling Stone" altered the range of popular music in 1965. His mid-1960s recordings, backed by rock musicians, reached the top end of the United States music charts while also attracting denunciation and criticism from others in the folk movement.

Dylan's lyrics have incorporated various political, social, philosophical, and literary influences. They defied existing pop music conventions and appealed to the burgeoning counterculture. Initially inspired by the performances of Little Richard, and the songwriting of Woody Guthrie, Robert Johnson, and Hank Williams, Dylan has amplified and personalized musical genres. His recording career, spanning 50 years, has explored the traditions in American song—from folk, blues, and country to gospel, rock and roll, and rockabilly to English, Scottish, and Irish folk music, embracing even jazz and the Great American Songbook. Dylan performs with guitar, keyboards, and harmonica. Backed by a changing line-up of musicians, he has toured steadily since the late 1980s on what has been dubbed the Never Ending Tour. His accomplishments as a recording artist and performer have been central to his career, but songwriting is considered his greatest contribution.
<br>
