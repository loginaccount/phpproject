
<br>
<br>
<img src='lab12/lab12images/guido.jpg'>

<br>
<br>
<h1>Guido of Arezzo</h1>

<br>

Guido of Arezzo (also Guido Aretinus, Guido Aretino, Guido da Arezzo, Guido Monaco, or Guido d'Arezzo, or Guy of Arezzo) (991/992 – after 1033) was an Italian music theorist of the Medieval era. He is regarded as the inventor of modern musical notation (staff notation) that replaced neumatic notation; his text, the Micrologus, was the second-most-widely distributed treatise on music in the Middle Ages (after the writings of Boethius).

Guido was a monk of the Benedictine order from the Italian city-state of Arezzo. Recent research has dated his Micrologus to 1025 or 1026; since Guido stated in a letter that he was thirty-four when he wrote it, his birthdate is presumed to be around 991 or 992. His early career was spent at the monastery of Pomposa, on the Adriatic coast near Ferrara. While there, he noted the difficulty that singers had in remembering Gregorian chants.

He came up with a method for teaching the singers to learn chants in a short time, and quickly became famous throughout north Italy. However, he attracted the hostility of the other monks at the abbey, prompting him to move to Arezzo, a town which had no abbey, but which did have a large group of cathedral singers, whose training Bishop Tedald invited him to conduct.
<br>