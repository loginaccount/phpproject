<br>
<br>
<img src='lab12/lab12images/robert.jpg'>
<br>

<br>
<h1>Robert Johnson</h1>

<br>

Robert Leroy Johnson (May 8, 1911 – August 16, 1938) was an American blues singer-songwriter and musician. His landmark recordings in 1936 and 1937 display a combination of singing, guitar skills, and songwriting talent that has influenced later generations of musicians. Johnson's shadowy and poorly documented life and death at age 27 have given rise to much legend, including the Faustian myth that he sold his soul to the devil at a crossroads to achieve success. As an itinerant performer who played mostly on street corners, in juke joints, and at Saturday night dances, Johnson had little commercial success or public recognition in his lifetime.

It was only after the reissue of his recordings in 1961, on the LP King of the Delta Blues Singers, that his work reached a wider audience. Johnson is now recognized as a master of the blues, particularly of the Mississippi Delta blues style. He is credited by many rock musicians as an important influence; Eric Clapton has called Johnson "the most important blues singer that ever lived."Johnson was inducted into the Rock and Roll Hall of Fame as an early Influence in their first induction ceremony in 1986. In 2010, David Fricke ranked Johnson fifth in Rolling Stone′s list of the 100 Greatest Guitarists of All Time.
<br>