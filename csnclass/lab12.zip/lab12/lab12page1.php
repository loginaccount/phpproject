<br>

<br>

<img src='lab12/lab12images/william.jpg'>


<br>
<br>
<h1>William James Hung </h1>

<br>


William James Hung (born January 13, 1983), also known as Hung Hing Cheong, is a Hong Kong-born American former singer who gained fame in early 2004 as a result of his off-key audition performance of Ricky Martin's hit song "She Bangs" on the third season of the television series American Idol.

At the time of his audition, Hung was a civil engineering student at UC Berkeley. After his spirited audition to be the next American Idol, he inadvertently won the support of many fans. Hung voluntarily left university to pursue a music career. His recording career was marked by constant negative critical reaction, and his fame became the subject of much controversy as both he and his fans were accused of promoting and endorsing racial stereotypes against Asians, as he was perceived to lack musical talent and be celebrated only for embodying these stereotypes. In spite of the criticism and the implications of his success, he only showed signs of thoroughly enjoying his celebrity, believing he was living his dream.

He brought his own career as a musician to an end when in 2011 he accepted a job opportunity as a technical crime analyst for the Los Angeles County Sheriff's Department, and decided to pursue law enforcement instead of music. Since then, Hung has reflected positively on his pop music career.



<br>